"use client";

import { useState, ChangeEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Loader2, UploadCloud, CheckCircle, AlertTriangle, Sparkles } from 'lucide-react';
import { suggestDonationItems, SuggestDonationItemsOutput } from '@/ai/flows/suggest-donation-items';
import Image from 'next/image';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '../ui/card';
import Link from 'next/link';

export function SuggestDonationItemsComponent() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<SuggestDonationItemsOutput | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "File too large",
          description: "Please upload an image smaller than 5MB.",
          variant: "destructive",
        });
        return;
      }
      setFile(selectedFile);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
      setSuggestions(null); // Clear previous suggestions
      setError(null); // Clear previous errors
    }
  };

  const handleSubmit = async () => {
    if (!file || !preview) {
      toast({ title: "No file selected", description: "Please select an image to upload.", variant: "destructive" });
      return;
    }

    setIsLoading(true);
    setSuggestions(null);
    setError(null);

    try {
      const photoDataUri = preview; // Already in base64 from FileReader
      const result = await suggestDonationItems({ photoDataUri });
      setSuggestions(result);
      toast({
        title: "Suggestions Ready!",
        description: "AI has analyzed your photo.",
        variant: "default",
        className: "bg-green-50 border-green-200 text-green-700"
      });
    } catch (err) {
      console.error("Error suggesting donation items:", err);
      const errorMessage = err instanceof Error ? err.message : "An unknown error occurred.";
      setError(`Failed to get suggestions: ${errorMessage}`);
      toast({
        title: "Error",
        description: `Could not get suggestions. ${errorMessage}`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <label htmlFor="photoUpload" className="block text-sm font-medium text-foreground mb-1">
          Upload Photo of Cluttered Space
        </label>
        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md cursor-pointer bg-muted/50 hover:bg-muted/75 transition-colors relative">
          {preview ? (
            <div className="relative w-full max-h-80 flex justify-center">
               <Image src={preview} alt="Uploaded preview" layout="intrinsic" width={300} height={300} objectFit="contain" className="rounded-md" data-ai-hint="cluttered space"/>
            </div>
          ) : (
            <div className="space-y-1 text-center">
              <UploadCloud className="mx-auto h-12 w-12 text-gray-400" />
              <div className="flex text-sm text-gray-600">
                <span className="relative rounded-md font-medium text-primary hover:text-primary/80 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-ring">
                  <span>Upload a file</span>
                </span>
                <p className="pl-1">or drag and drop</p>
              </div>
              <p className="text-xs text-gray-500">PNG, JPG, GIF up to 5MB</p>
            </div>
          )}
          <Input id="photoUpload" name="photoUpload" type="file" accept="image/*" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" onChange={handleFileChange} />
        </div>
      </div>

      {file && (
        <Button onClick={handleSubmit} disabled={isLoading} className="w-full bg-accent text-accent-foreground hover:bg-accent/90 text-lg py-3">
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Analyzing...
            </>
          ) : (
             <>
              <Sparkles className="mr-2 h-5 w-5" /> Get AI Suggestions
            </>
          )}
        </Button>
      )}

      {error && (
        <Card className="border-destructive bg-destructive/10">
          <CardHeader>
            <CardTitle className="text-destructive flex items-center">
              <AlertTriangle className="mr-2 h-5 w-5" /> Error
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-destructive">{error}</p>
          </CardContent>
        </Card>
      )}

      {suggestions && suggestions.suggestedItems.length > 0 && (
        <Card className="border-green-500 bg-green-50 shadow-lg">
          <CardHeader>
            <CardTitle className="text-green-700 flex items-center">
              <CheckCircle className="mr-2 h-6 w-6" /> AI Suggested Items for Donation:
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside space-y-2 text-green-800">
              {suggestions.suggestedItems.map((item, index) => (
                <li key={index} className="text-md">{item}</li>
              ))}
            </ul>
            <p className="mt-4 text-sm text-green-600">
              These are just suggestions! Please review them and decide what you'd like to donate.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/donations/add" passHref>
               <Button className="bg-primary hover:bg-primary/90 w-full">
                List a Donation Now
              </Button>
            </Link>
          </CardFooter>
        </Card>
      )}
      {suggestions && suggestions.suggestedItems.length === 0 && (
         <Card className="border-blue-500 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-blue-700 flex items-center">
              <Sparkles className="mr-2 h-6 w-6" /> No Specific Items Detected
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-blue-800">The AI couldn't identify specific items to suggest from this photo, or it looks like things are quite tidy!
            <br />Feel free to try another photo or list items manually.</p>
          </CardContent>
           <CardFooter>
            <Link href="/donations/add" passHref>
               <Button className="bg-primary hover:bg-primary/90 w-full">
                List a Donation Manually
              </Button>
            </Link>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
