
"use client";

import type { DonationItem } from '@/lib/types';
import { placeholderDonations } from '@/lib/placeholder-data';
import Link from 'next/link';
import Image from 'next/image';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertTriangle, ListChecks, Wrench } from 'lucide-react';

interface PendingRepairsSectionProps {
  userId: string;
}

// Helper to format date
const formatDate = (date?: Date | string): string => {
  if (!date) return 'N/A';
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric'
  });
};

export function PendingRepairsSection({ userId }: PendingRepairsSectionProps) {
  const itemsPendingRepair = placeholderDonations.filter(
    (donation) => donation.donorId === userId && donation.status === 'pending repair'
  );

  if (itemsPendingRepair.length === 0) {
    return (
      <Card className="shadow-md border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="text-lg text-primary flex items-center">
            <ListChecks className="mr-2 h-5 w-5" />
            All Items Accounted For
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">You have no items currently marked as needing repair. Great job keeping things ready for donation!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg border-orange-400 bg-orange-50">
      <CardHeader>
        <CardTitle className="text-xl text-orange-700 flex items-center">
           <Wrench className="mr-2 h-6 w-6"/> Manage Your Fixable Donations
        </CardTitle>
        <CardDescription className="text-orange-600">
          These items are marked as needing repair. Update them once they are fixed and ready to be claimed.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {itemsPendingRepair.map((item) => (
          <div key={item.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 border bg-background rounded-lg shadow-sm gap-3">
            <div className="flex items-center gap-3 flex-grow">
                <Image
                    src={item.imageUrl || `https://picsum.photos/seed/${item.id}/60/60`}
                    alt={item.title}
                    data-ai-hint="donation item small"
                    width={60}
                    height={60}
                    className="rounded-md object-cover aspect-square"
                />
                <div>
                    <p className="font-semibold text-primary">{item.title}</p>
                    <p className="text-xs text-muted-foreground">
                        Listed: {formatDate(item.createdAt)} | Condition: <span className="capitalize">{item.condition}</span>
                    </p>
                    {item.damageDescription && (
                         <p className="text-xs text-orange-600 mt-1 truncate" title={item.damageDescription}>
                            Damage: {item.damageDescription.length > 50 ? item.damageDescription.substring(0, 47) + "..." : item.damageDescription}
                        </p>
                    )}
                </div>
            </div>
            <Link href={`/donations/${item.id}`} passHref className="w-full sm:w-auto">
              <Button variant="outline" size="sm" className="w-full sm:w-auto border-orange-500 text-orange-600 hover:bg-orange-100 hover:text-orange-700">
                View & Update Repair
              </Button>
            </Link>
          </div>
        ))}
      </CardContent>
       {itemsPendingRepair.length > 0 && (
        <CardFooter>
            <p className="text-xs text-muted-foreground">
                Visit the item's detail page to find repair partner suggestions or to mark it as repaired.
            </p>
        </CardFooter>
       )}
    </Card>
  );
}
