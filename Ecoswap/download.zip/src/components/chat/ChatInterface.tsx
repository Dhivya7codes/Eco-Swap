"use client";

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { UserProfile, ChatMessage as ChatMessageType } from '@/lib/types';
import { Send, Paperclip } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ChatInterfaceProps {
  currentUser: UserProfile;
  otherUserId: string; // This should be the actual ID of the other user in chat
  donationId: string; // To scope the chat to a donation
}

// Mock messages - in a real app, this would come from Firebase/Socket.io
const mockMessages: ChatMessageType[] = [
    { id: 'msg1', chatId: 'donation1', senderId: 'donor123', receiverId: 'ngo456', text: 'Hello! I saw you claimed my winter jackets. When would be a good time for pickup?', timestamp: new Date(Date.now() - 5 * 60 * 1000), isRead: true },
    { id: 'msg2', chatId: 'donation1', senderId: 'ngo456', receiverId: 'donor123', text: 'Hi John! Thanks for donating. How about tomorrow around 2 PM?', timestamp: new Date(Date.now() - 4 * 60 * 1000), isRead: true },
    { id: 'msg3', chatId: 'donation1', senderId: 'donor123', receiverId: 'ngo456', text: '2 PM works perfectly for me!', timestamp: new Date(Date.now() - 3 * 60 * 1000), isRead: true },
    { id: 'msg4', chatId: 'donation1', senderId: 'ngo456', receiverId: 'donor123', text: 'Great, see you then!', timestamp: new Date(Date.now() - 2 * 60 * 1000) },
];


export function ChatInterface({ currentUser, otherUserId, donationId }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Filter mock messages for this specific chat
  useEffect(() => {
    const relevantMessages = mockMessages.filter(
      msg => msg.chatId === donationId && 
             ((msg.senderId === currentUser.id && msg.receiverId === otherUserId) || 
              (msg.senderId === otherUserId && msg.receiverId === currentUser.id))
    );
    setMessages(relevantMessages);
  }, [donationId, currentUser.id, otherUserId]);


  useEffect(() => {
    // Auto-scroll to bottom
    if (scrollAreaRef.current) {
      const scrollViewport = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollViewport) {
        scrollViewport.scrollTop = scrollViewport.scrollHeight;
      }
    }
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim() === '') return;

    const messageToSend: ChatMessageType = {
      id: `msg${Date.now()}`,
      chatId: donationId,
      senderId: currentUser.id,
      receiverId: otherUserId,
      text: newMessage,
      timestamp: new Date(),
    };

    setMessages(prevMessages => [...prevMessages, messageToSend]);
    setNewMessage('');

    // In a real app, send this message via Socket.io or save to Firebase
    console.log("Sending message:", messageToSend);
  };

  return (
    <div className="flex flex-col h-full max-h-[calc(100vh-18rem)] md:max-h-[calc(100vh-16rem)] bg-card rounded-lg">
      <ScrollArea className="flex-grow p-4" ref={scrollAreaRef}>
        <div className="space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={cn(
                "flex items-end space-x-2 max-w-[80%]",
                msg.senderId === currentUser.id ? "ml-auto flex-row-reverse space-x-reverse" : ""
              )}
            >
              <Avatar className="h-8 w-8">
                <AvatarImage src={msg.senderId === currentUser.id ? currentUser.profilePicUrl : `https://picsum.photos/seed/${otherUserId}/40/40`} data-ai-hint="profile avatar" />
                <AvatarFallback>{(msg.senderId === currentUser.id ? currentUser.name : 'O').charAt(0)}</AvatarFallback>
              </Avatar>
              <div
                className={cn(
                  "p-3 rounded-lg shadow-md",
                  msg.senderId === currentUser.id
                    ? "bg-primary text-primary-foreground rounded-br-none"
                    : "bg-muted text-muted-foreground rounded-bl-none"
                )}
              >
                <p className="text-sm">{msg.text}</p>
                <p className={cn(
                    "text-xs mt-1",
                    msg.senderId === currentUser.id ? "text-primary-foreground/70 text-right" : "text-muted-foreground/70 text-left"
                )}>
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
      <form onSubmit={handleSendMessage} className="border-t p-4 flex items-center space-x-2 bg-background">
        <Button type="button" variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
          <Paperclip className="h-5 w-5" />
          <span className="sr-only">Attach file</span>
        </Button>
        <Input
          type="text"
          placeholder="Type your message..."
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          className="flex-grow"
          autoComplete="off"
        />
        <Button type="submit" size="icon" className="bg-primary hover:bg-primary/90">
          <Send className="h-5 w-5" />
          <span className="sr-only">Send message</span>
        </Button>
      </form>
    </div>
  );
}
