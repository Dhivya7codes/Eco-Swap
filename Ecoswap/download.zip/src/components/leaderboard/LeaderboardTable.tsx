"use client";

import type { LeaderboardEntry } from '@/lib/types';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Award, Star } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface LeaderboardTableProps {
  data: LeaderboardEntry[];
}

export function LeaderboardTable({ data }: LeaderboardTableProps) {
  if (data.length === 0) {
    return <p className="text-center text-muted-foreground py-8">No leaderboard data available for this category.</p>;
  }

  const getRankColor = (rank: number) => {
    if (rank === 1) return 'text-yellow-500'; // Gold
    if (rank === 2) return 'text-gray-400';  // Silver
    if (rank === 3) return 'text-yellow-700';// Bronze (using a Tailwind color that resembles bronze)
    return 'text-foreground';
  };

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[80px] text-center">Rank</TableHead>
            <TableHead>User / Organization</TableHead>
            <TableHead className="text-right">EcoPoints</TableHead>
            <TableHead className="hidden md:table-cell text-center">Role</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((entry) => (
            <TableRow key={entry.userId} className="hover:bg-muted/50">
              <TableCell className={`font-bold text-lg text-center ${getRankColor(entry.rank)}`}>
                <div className="flex items-center justify-center">
                  {entry.rank <= 3 && <Award className={`mr-1 h-5 w-5 ${getRankColor(entry.rank)}`} />}
                  {entry.rank}
                </div>
              </TableCell>
              <TableCell>
                <div className="flex items-center space-x-3">
                  <Avatar className="h-10 w-10 border-2 border-primary/50">
                    <AvatarImage src={entry.userProfilePicUrl || undefined} alt={entry.userName} data-ai-hint="profile avatar" />
                    <AvatarFallback>{entry.userName.charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-foreground">{entry.userName}</p>
                    <p className="text-xs text-muted-foreground">ID: ...{entry.userId.slice(-6)}</p>
                  </div>
                </div>
              </TableCell>
              <TableCell className="text-right">
                <div className="flex items-center justify-end font-semibold text-primary">
                  <Star className="h-4 w-4 mr-1 text-yellow-400 fill-yellow-400" />
                  {entry.ecoPoints.toLocaleString()}
                </div>
              </TableCell>
              <TableCell className="hidden md:table-cell text-center">
                <Badge variant={entry.userRole === 'donor' ? 'default' : 'secondary'} className="capitalize">
                    {entry.userRole}
                </Badge>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
