"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea"; // Assuming Textarea for address
import { useAuth } from "@/context/AuthContext";
import type { UserProfile } from "@/lib/types";
import { toast } from "@/hooks/use-toast";
import { Loader2, Upload } from "lucide-react";
import { useState, ChangeEvent } from "react";
import Image from "next/image";

const profileFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Invalid email address." }).optional(), // Email might not be editable
  phone: z.string().optional(),
  address: z.string().optional(),
  profilePicUrl: z.string().url({ message: "Invalid URL for profile picture." }).optional(),
});

interface EditProfileFormProps {
  user: UserProfile;
}

export function EditProfileForm({ user }: EditProfileFormProps) {
  const { updateProfile } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [profilePicPreview, setProfilePicPreview] = useState<string | null>(user.profilePicUrl || null);

  const form = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      name: user.name || "",
      email: user.email || "", // Usually not editable, but included for completeness
      phone: user.phone || "",
      address: user.address || "",
      profilePicUrl: user.profilePicUrl || "",
    },
  });

  const handleProfilePicChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePicPreview(reader.result as string);
        // In a real app, you'd upload this file and get back a URL.
        // For mock, we'll just use the data URL or a placeholder.
        form.setValue("profilePicUrl", reader.result as string); 
      };
      reader.readAsDataURL(file);
    }
  };

  async function onSubmit(values: z.infer<typeof profileFormSchema>) {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    updateProfile({
      ...values,
      // If profilePicUrl is a data URL from preview, you might want to handle it differently
      // For this mock, we assume it's either the existing URL or a new (data) URL
      profilePicUrl: profilePicPreview || values.profilePicUrl, 
    });
    
    toast({
      title: "Profile Updated",
      description: "Your profile information has been successfully updated.",
    });
    setIsLoading(false);
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="profilePicUrl"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Profile Picture</FormLabel>
              <div className="flex items-center gap-4">
                {profilePicPreview && (
                  <Image 
                    src={profilePicPreview} 
                    alt="Profile preview" 
                    width={80} 
                    height={80} 
                    className="rounded-full object-cover"
                    data-ai-hint="profile avatar" 
                  />
                )}
                <FormControl>
                  <Button type="button" variant="outline" asChild>
                    <label htmlFor="profilePicUpload" className="cursor-pointer flex items-center">
                      <Upload className="mr-2 h-4 w-4" /> Change Picture
                      <Input id="profilePicUpload" type="file" accept="image/*" className="hidden" onChange={handleProfilePicChange} />
                    </label>
                  </Button>
                </FormControl>
              </div>
              <FormDescription>Upload a new profile picture. JPG, PNG, GIF accepted.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Full Name</FormLabel>
              <FormControl>
                <Input placeholder="Your full name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input placeholder="your@email.com" {...field} disabled />
              </FormControl>
              <FormDescription>Email address cannot be changed.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="phone"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Phone Number</FormLabel>
              <FormControl>
                <Input placeholder="Your phone number" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="address"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Address</FormLabel>
              <FormControl>
                <Textarea placeholder="Your full address" {...field} className="min-h-[100px]" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" className="bg-primary hover:bg-primary/90" disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Save Changes
        </Button>
      </form>
    </Form>
  );
}
