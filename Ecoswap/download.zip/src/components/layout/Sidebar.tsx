"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Sidebar as UISidebar,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Leaf, Home, PlusCircle, ListChecks, Users, BarChart3, MessageSquare, Settings, LogOut, Zap, Lightbulb, ShieldCheck } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";

const commonNavItems = [
  { href: "/dashboard", label: "Dashboard", icon: Home },
  { href: "/donations", label: "Browse Donations", icon: ListChecks },
  { href: "/chat", label: "Chat", icon: MessageSquare },
  { href: "/leaderboard", label: "Leaderboard", icon: BarChart3 },
];

const donorNavItems = [
  { href: "/donations/add", label: "Add Donation", icon: PlusCircle },
  { href: "/suggest-donations", label: "AI Suggestions", icon: Lightbulb },
  { href: "/donations/history", label: "My Donations", icon: Zap },
];

const ngoNavItems = [
  { href: "/donations/claimed", label: "Claimed Items", icon: ShieldCheck },
];

const receiverNavItems = [
   { href: "/donations/claimed", label: "My Claims", icon: ShieldCheck },
];


export function Sidebar() {
  const pathname = usePathname();
  const { role, logout, user } = useAuth();

  let navItems = [...commonNavItems];
  if (role === 'donor') {
    navItems = [...navItems, ...donorNavItems];
  } else if (role === 'ngo') {
    navItems = [...navItems, ...ngoNavItems];
  } else if (role === 'receiver') {
    navItems = [...navItems, ...receiverNavItems];
  }

  return (
    <UISidebar collapsible="icon" side="left" variant="sidebar">
      <SidebarHeader className="p-4 flex items-center justify-between">
        <Link href="/dashboard" className="flex items-center gap-2 text-lg font-semibold md:text-base">
          <Leaf className={cn("h-7 w-7 text-sidebar-primary transition-all group-data-[collapsible=icon]:h-8 group-data-[collapsible=icon]:w-8")} />
          <span className="font-bold text-sidebar-foreground transition-all group-data-[collapsible=icon]:opacity-0 group-data-[collapsible=icon]:hidden">EcoSwap</span>
        </Link>
        <div className="block md:hidden">
          <SidebarTrigger />
        </div>
      </SidebarHeader>
      <SidebarContent className="p-2">
        <SidebarMenu>
          {navItems.map((item) => (
            <SidebarMenuItem key={item.href}>
              <Link href={item.href} passHref legacyBehavior>
                <SidebarMenuButton
                  isActive={pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href))}
                  tooltip={item.label}
                  className={cn(
                    "justify-start",
                    (pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href)))
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  )}
                >
                  <item.icon className="h-5 w-5" />
                  <span className="transition-all group-data-[collapsible=icon]:opacity-0 group-data-[collapsible=icon]:hidden">{item.label}</span>
                </SidebarMenuButton>
              </Link>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="p-4 mt-auto border-t border-sidebar-border">
        <Link href="/profile" passHref legacyBehavior>
          <SidebarMenuButton
            tooltip="Profile"
            className={cn(
              "justify-start mb-2",
              pathname === "/profile"
              ? "bg-sidebar-accent text-sidebar-accent-foreground"
              : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            )}
          >
            <Users className="h-5 w-5" />
            <span className="transition-all group-data-[collapsible=icon]:opacity-0 group-data-[collapsible=icon]:hidden">Profile</span>
          </SidebarMenuButton>
        </Link>
        <Button
          variant="ghost"
          className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground group-data-[collapsible=icon]:justify-center"
          onClick={logout}
        >
          <LogOut className="h-5 w-5" />
          <span className="ml-2 transition-all group-data-[collapsible=icon]:opacity-0 group-data-[collapsible=icon]:hidden">Logout</span>
        </Button>
      </SidebarFooter>
    </UISidebar>
  );
}
