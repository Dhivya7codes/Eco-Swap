"use client";

import type { DonationItem } from '@/lib/types';
import { DonationCard } from './DonationCard';

interface DonationListProps {
  donations: DonationItem[];
}

export function DonationList({ donations }: DonationListProps) {
  if (donations.length === 0) {
    return <p className="text-center text-muted-foreground py-8">No donations available at the moment.</p>;
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {donations.map((donation) => (
        <DonationCard key={donation.id} donation={donation} />
      ))}
    </div>
  );
}
