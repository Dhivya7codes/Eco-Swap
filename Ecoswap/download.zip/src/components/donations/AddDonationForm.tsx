
"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Checkbox } from "@/components/ui/checkbox"; // Import Checkbox
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { CalendarIcon, Loader2, UploadCloud, Wrench } from "lucide-react"; // Added Wrench icon
import { useAuth } from "@/context/AuthContext";
import { toast } from "@/hooks/use-toast";
import { useState, ChangeEvent } from "react";
import Image from "next/image";
import type { DonationCategory, DonationCondition } from "@/lib/types";

const donationCategories: DonationCategory[] = ["clothing", "electronics", "furniture", "books", "toys", "kitchenware", "other"];
const donationConditions: DonationCondition[] = ["new", "like new", "good", "fair", "needs repair"]; // Added 'needs repair'

const addDonationFormSchema = z.object({
  title: z.string().min(5, { message: "Title must be at least 5 characters." }),
  description: z.string().min(10, { message: "Description must be at least 10 characters." }),
  category: z.enum(donationCategories, { required_error: "Please select a category." }),
  condition: z.enum(donationConditions, { required_error: "Please select the item's condition." }),
  location: z.string().min(3, { message: "Location is required." }),
  imageUrl: z.string().url({ message: "Please upload an image or provide a valid URL." }).optional(),
  availability: z.string().min(1, { message: "Availability details are required (e.g., '1 item', '2 bags')." }),
  pickupSlot: z.date().optional(),
  needsRepair: z.boolean().default(false).optional(),
  damageDescription: z.string().optional(),
}).refine(data => {
  // If needsRepair is true or condition is 'needs repair', damageDescription must be provided
  if ((data.needsRepair || data.condition === 'needs repair') && (!data.damageDescription || data.damageDescription.trim().length < 10)) {
    return false;
  }
  return true;
}, {
  message: "Please describe the damage (min 10 characters) if the item needs repair.",
  path: ["damageDescription"], // Apply error to damageDescription field
});

export function AddDonationForm() {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [itemImagePreview, setItemImagePreview] = useState<string | null>(null);

  const form = useForm<z.infer<typeof addDonationFormSchema>>({
    resolver: zodResolver(addDonationFormSchema),
    defaultValues: {
      title: "",
      description: "",
      location: "",
      availability: "",
      needsRepair: false,
      damageDescription: "",
    },
  });

  // Watch the needsRepair field to conditionally show the damage description
  const needsRepairValue = form.watch("needsRepair");
  const conditionValue = form.watch("condition");

  const handleItemImageChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setItemImagePreview(reader.result as string);
        // In a real app, upload and get URL. For mock, use data URL or placeholder.
        form.setValue("imageUrl", reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  async function onSubmit(values: z.infer<typeof addDonationFormSchema>) {
    if (!user) {
      toast({ title: "Error", description: "You must be logged in to add a donation.", variant: "destructive" });
      return;
    }
    setIsLoading(true);

    // Ensure needsRepair is true if condition is 'needs repair'
    const finalNeedsRepair = values.needsRepair || values.condition === 'needs repair';

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    const newDonation = {
      ...values,
      id: `donation-${Date.now()}`, // Mock ID
      donorId: user.id,
      donorName: user.name, // Add donor name
      status: finalNeedsRepair ? "pending repair" : "available", // Set status based on repair need
      createdAt: new Date(),
      updatedAt: new Date(),
      imageUrl: itemImagePreview || values.imageUrl, // ensure preview is used if available
      needsRepair: finalNeedsRepair,
      damageDescription: finalNeedsRepair ? values.damageDescription : undefined, // Clear damage description if not needed
    };
    console.log("New Donation Submitted:", newDonation);
    // In a real app, you'd send this to your backend to save.
    // And potentially add to a global state / re-fetch donations.
    // For mock, let's add to placeholder data if needed for testing flow (ensure imported)
    // import { placeholderDonations } from '@/lib/placeholder-data';
    // placeholderDonations.push(newDonation as any); // Add to mock data

    toast({
      title: "Donation Listed!",
      description: `Your item "${values.title}" has been successfully listed${finalNeedsRepair ? ' (marked as needs repair)' : ''}.`,
    });
    form.reset();
    setItemImagePreview(null);
    setIsLoading(false);
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <FormField
          control={form.control}
          name="imageUrl"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Item Image</FormLabel>
              <FormControl>
                <label htmlFor="itemImageUpload" className="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer bg-muted/50 hover:bg-muted/75 transition-colors">
                  {itemImagePreview ? (
                    <Image src={itemImagePreview} alt="Item preview" width={200} height={200} className="max-h-full max-w-full object-contain rounded-md" data-ai-hint="donated item" />
                  ) : (
                    <div className="flex flex-col items-center justify-center pt-5 pb-6 text-center">
                      <UploadCloud className="w-10 h-10 mb-3 text-gray-400" />
                      <p className="mb-2 text-sm text-gray-500 dark:text-gray-400"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">SVG, PNG, JPG or GIF (MAX. 800x400px)</p>
                    </div>
                  )}
                  <Input id="itemImageUpload" type="file" accept="image/*" className="hidden" onChange={handleItemImageChange} />
                 </label>
              </FormControl>
              <FormDescription>A clear image helps your item get claimed faster.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Item Title</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Warm Winter Coat, Set of Novels" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea placeholder="Provide details about the item, its size, any specific features, etc." className="min-h-[120px]" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="category"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Category</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {donationCategories.map(cat => (
                      <SelectItem key={cat} value={cat} className="capitalize">{cat.charAt(0).toUpperCase() + cat.slice(1)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="condition"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Condition</FormLabel>
                <Select onValueChange={(value) => {
                    field.onChange(value);
                    // Automatically check "Needs Repair" if condition is set to "needs repair"
                    if (value === 'needs repair') {
                      form.setValue('needsRepair', true);
                    } else {
                      // Optionally uncheck if condition changed away from "needs repair"
                       form.setValue('needsRepair', false);
                    }
                }} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select item condition" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {donationConditions.map(cond => (
                       <SelectItem key={cond} value={cond} className="capitalize">{cond.charAt(0).toUpperCase() + cond.slice(1)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* Needs Repair Checkbox */}
         <FormField
          control={form.control}
          name="needsRepair"
          render={({ field }) => (
            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 shadow-sm bg-muted/30">
              <FormControl>
                <Checkbox
                  checked={field.value || conditionValue === 'needs repair'} // Keep checked if condition is 'needs repair'
                  onCheckedChange={(checked) => {
                      field.onChange(checked);
                      // If checked, set condition to 'needs repair' if not already set
                      if (checked && form.getValues('condition') !== 'needs repair') {
                        form.setValue('condition', 'needs repair');
                      }
                      // If unchecked, reset condition if it was 'needs repair'
                      else if (!checked && form.getValues('condition') === 'needs repair') {
                         form.setValue('condition', 'fair'); // Or prompt user? Default to 'fair' for now
                      }
                  }}
                  disabled={conditionValue === 'needs repair'} // Disable checkbox if condition forces it
                />
              </FormControl>
              <div className="space-y-1 leading-none">
                <FormLabel className="flex items-center">
                   <Wrench className="mr-2 h-4 w-4 text-orange-600"/> Item Needs Repair?
                </FormLabel>
                <FormDescription>
                  Check this box if the item has damage (e.g., torn, broken, malfunctioning) but could be fixed.
                </FormDescription>
              </div>
            </FormItem>
          )}
        />

        {/* Conditional Damage Description */}
        {(needsRepairValue || conditionValue === 'needs repair') && (
          <FormField
            control={form.control}
            name="damageDescription"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Describe the Damage</FormLabel>
                <FormControl>
                  <Textarea placeholder="e.g., 'Torn seam on left sleeve', 'Screen flickers sometimes', 'Missing one button'" className="min-h-[100px]" {...field} />
                </FormControl>
                <FormDescription>Please provide specific details about what needs fixing.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        )}


        <FormField
          control={form.control}
          name="location"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Pickup Location</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Your neighborhood or a nearby landmark" {...field} />
              </FormControl>
              <FormDescription>Be specific enough for NGOs/receivers to understand the area.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="availability"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Quantity / Availability</FormLabel>
              <FormControl>
                <Input placeholder="e.g., '1 chair', '3 bags of clothes', 'Approx. 10 books'" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="pickupSlot"
          render={({ field }) => (
            <FormItem className="flex flex-col">
              <FormLabel>Preferred Pickup Time (Optional)</FormLabel>
              <Popover>
                <PopoverTrigger asChild>
                  <FormControl>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full pl-3 text-left font-normal",
                        !field.value && "text-muted-foreground"
                      )}
                    >
                      {field.value ? (
                        format(field.value, "PPP HH:mm") // Example including time
                      ) : (
                        <span>Pick a date and time</span>
                      )}
                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                    </Button>
                  </FormControl>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={field.value}
                    onSelect={field.onChange}
                    disabled={(date) => date < new Date(new Date().setHours(0,0,0,0)) } // Disable past dates
                    initialFocus
                  />
                  {/* Basic time picker example - ideally use a dedicated time picker component */}
                  <div className="p-2 border-t">
                    <Input
                      type="time"
                      defaultValue={field.value ? format(field.value, "HH:mm") : ""}
                      onChange={(e) => {
                        if (field.value) {
                          const [hours, minutes] = e.target.value.split(':').map(Number);
                          const newDate = new Date(field.value);
                          newDate.setHours(hours, minutes);
                          field.onChange(newDate);
                        } else {
                           // if no date is set, maybe set current date with this time?
                           // for now, time input requires a date to be selected first
                        }
                      }}
                    />
                  </div>
                </PopoverContent>
              </Popover>
              <FormDescription>
                Suggest a convenient time for pickup. This can be coordinated later via chat.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-lg py-3" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Listing Item...
            </>
          ) : (
            "List My Donation"
          )}
        </Button>
      </form>
    </Form>
  );
}
