"use client";

import Image from 'next/image';
import type { DonationItem } from '@/lib/types';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tag, MapPin, CalendarDays, Layers, ShieldCheck, ArrowRight, Wrench } from 'lucide-react'; // Added Wrench
import { useAuth } from '@/context/AuthContext';
import { toast } from '@/hooks/use-toast';
import Link from 'next/link'; // Import Link
import { cn } from '@/lib/utils'; // Import cn

// Helper function to format date
const formatDate = (date?: Date | string): string => {
  if (!date) return 'N/A';
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric'
  });
};

interface DonationCardProps {
  donation: DonationItem;
}

export function DonationCard({ donation }: DonationCardProps) {
  const { user, role } = useAuth();

  const handleClaim = () => {
    if (!user) {
      toast({ title: "Login Required", description: "Please login to claim items.", variant: "destructive"});
      return;
    }
    if (role === 'donor') {
      toast({ title: "Action Not Allowed", description: "Donors cannot claim items.", variant: "destructive"});
      return;
    }
     if (donation.status === 'pending repair') {
      toast({ title: "Needs Repair", description: "This item needs repair before it can be claimed.", variant: "default"});
      return;
    }
    // Placeholder for claim logic
    console.log(`User ${user.id} (${role}) attempting to claim item ${donation.id}`);
    toast({ title: "Item Claimed (Mock)", description: `You have claimed "${donation.title}". Coordination details will follow.`});
    // Here you would update the donation status, notify the donor, etc.
    // For now, we'll just log and toast. The item card itself won't update status in this mock.
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-100 text-green-700 border-green-300';
      case 'claimed': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'picked up': return 'bg-blue-100 text-blue-700 border-blue-300';
      case 'delivered': return 'bg-purple-100 text-purple-700 border-purple-300';
      case 'pending repair': return 'bg-orange-100 text-orange-700 border-orange-300'; // Added color for pending repair
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };


  return (
    <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col h-full">
      <CardHeader className="p-0 relative">
        <Image
          src={donation.imageUrl || `https://picsum.photos/seed/${donation.id}/400/250`}
          alt={donation.title}
          data-ai-hint="donation item"
          width={400}
          height={250}
          className="object-cover w-full h-48"
        />
         <div className="absolute top-2 right-2 flex flex-col items-end space-y-1">
            <Badge className={cn(getStatusColor(donation.status), "capitalize")}>
              {donation.status}
            </Badge>
            {donation.needsRepair && donation.status !== 'pending repair' && ( // Show only if needs repair AND not already pending
              <Badge variant="destructive" className="bg-orange-500 text-white border-orange-700">
                <Wrench className="h-3 w-3 mr-1" /> Needs Repair
              </Badge>
            )}
         </div>
      </CardHeader>
      <CardContent className="p-4 flex-grow">
        <CardTitle className="text-xl mb-1 text-primary truncate" title={donation.title}>{donation.title}</CardTitle>
        <CardDescription className="text-sm text-muted-foreground h-10 overflow-hidden text-ellipsis mb-3">
          {donation.description}
        </CardDescription>

        <div className="space-y-1.5 text-xs text-foreground/80 mb-3">
          <div className="flex items-center">
            <Tag className="h-3.5 w-3.5 mr-1.5 text-accent" />
            Category: <span className="font-medium ml-1 capitalize">{donation.category}</span>
          </div>
          <div className="flex items-center">
            <ShieldCheck className="h-3.5 w-3.5 mr-1.5 text-accent" />
            Condition: <span className="font-medium ml-1 capitalize">{donation.condition}</span>
          </div>
          <div className="flex items-center">
            <Layers className="h-3.5 w-3.5 mr-1.5 text-accent" />
            Availability: <span className="font-medium ml-1">{donation.availability}</span>
          </div>
          <div className="flex items-center">
            <MapPin className="h-3.5 w-3.5 mr-1.5 text-accent" />
            Location: <span className="font-medium ml-1">{donation.location}</span>
          </div>
          <div className="flex items-center">
            <CalendarDays className="h-3.5 w-3.5 mr-1.5 text-accent" />
            Listed: <span className="font-medium ml-1">{formatDate(donation.createdAt)}</span>
          </div>
        </div>

      </CardContent>
      <CardFooter className="p-4 border-t flex-wrap gap-2"> {/* Added flex-wrap and gap */}
        {role !== 'donor' && donation.status === 'available' && (
          <Button onClick={handleClaim} className="flex-1 min-w-[120px] bg-accent text-accent-foreground hover:bg-accent/90"> {/* Use flex-1 and min-w */}
            Claim Item
          </Button>
        )}
         {donation.status === 'pending repair' && role !== 'donor' && (
           <Badge variant="outline" className="w-full justify-center border-orange-500 text-orange-600">Item needs repair before claiming</Badge>
         )}
        <Link href={`/donations/${donation.id}`} passHref legacyBehavior>
          <Button variant="outline" className="flex-1 min-w-[120px]"> {/* Use flex-1 and min-w */}
            View Details <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
