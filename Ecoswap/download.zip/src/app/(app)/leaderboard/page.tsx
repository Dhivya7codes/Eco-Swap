"use client";

import { LeaderboardTable } from '@/components/leaderboard/LeaderboardTable';
import { placeholderLeaderboard } from '@/lib/placeholder-data';
import type { LeaderboardEntry } from '@/lib/types';
import { Award, BarChart3, Users } from 'lucide-react';
import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

// Simulate fetching leaderboard data
async function fetchLeaderboard(filter: 'all' | 'donors' | 'ngos'): Promise<LeaderboardEntry[]> {
  await new Promise(resolve => setTimeout(resolve, 300));
  let data = placeholderLeaderboard;
  if (filter === 'donors') {
    data = placeholderLeaderboard.filter(entry => entry.userRole === 'donor');
  } else if (filter === 'ngos') {
    data = placeholderLeaderboard.filter(entry => entry.userRole === 'ngo');
  }
  // Re-rank based on filter
  return data.sort((a,b) => b.ecoPoints - a.ecoPoints).map((entry, index) => ({ ...entry, rank: index + 1 }));
}


export default function LeaderboardPage() {
  const [leaderboardData, setLeaderboardData] = useState<LeaderboardEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | 'donors' | 'ngos'>('all');

  useEffect(() => {
    async function loadLeaderboard() {
      setIsLoading(true);
      const data = await fetchLeaderboard(activeTab);
      setLeaderboardData(data);
      setIsLoading(false);
    }
    loadLeaderboard();
  }, [activeTab]);

  return (
    <div className="container mx-auto py-8 px-4 md:px-0">
      <div className="flex items-center mb-4">
        <BarChart3 className="h-10 w-10 text-primary mr-3" />
        <h1 className="text-4xl font-bold text-primary">EcoPoints Leaderboard</h1>
      </div>
      <p className="text-lg text-muted-foreground mb-8">
        See who is making the biggest impact in our community! Points are awarded for donations and other positive actions.
      </p>

      <Tabs defaultValue="all" onValueChange={(value) => setActiveTab(value as 'all' | 'donors' | 'ngos')} className="w-full">
        <TabsList className="grid w-full grid-cols-3 md:w-1/2 mb-6">
          <TabsTrigger value="all">
            <Users className="mr-2 h-4 w-4" /> All
          </TabsTrigger>
          <TabsTrigger value="donors">
            <Award className="mr-2 h-4 w-4" /> Top Donors
          </TabsTrigger>
          <TabsTrigger value="ngos">
            <Award className="mr-2 h-4 w-4" /> Top NGOs
          </TabsTrigger>
        </TabsList>
        
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl">
              {activeTab === 'all' && 'Overall Top Contributors'}
              {activeTab === 'donors' && 'Top Donors'}
              {activeTab === 'ngos' && 'Top NGOs'}
            </CardTitle>
            <CardDescription>Monthly rankings based on EcoPoints earned.</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center items-center py-10">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                <p className="ml-4 text-muted-foreground">Loading leaderboard...</p>
              </div>
            ) : (
              <LeaderboardTable data={leaderboardData} />
            )}
          </CardContent>
        </Card>
      </Tabs>
      
      <Card className="mt-8 bg-primary/10 border-primary/30">
        <CardHeader>
          <CardTitle className="text-xl text-primary">How EcoPoints Work</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-foreground/80 space-y-2">
          <p>EcoPoints are our way of recognizing your valuable contributions to sustainability and community support.</p>
          <ul className="list-disc list-inside pl-4">
            <li>Earn points for each successful donation (based on item type, condition, and utility).</li>
            <li>Participate in special donation drives for bonus points.</li>
            <li>NGOs can earn points for facilitating large numbers of donations or impactful distributions.</li>
          </ul>
          <p className="mt-2">Redeem your EcoPoints for exciting rewards and partner offers (coming soon)!</p>
        </CardContent>
      </Card>
    </div>
  );
}
