"use client";

import { MessageSquare } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";

// Mock chat list data
const mockChats = [
  { id: "chat1", name: "John Doe (Donation: Winter Jackets)", lastMessage: "Yes, I can be there at 2 PM.", unread: 0, donationId: "donation1" },
  { id: "chat2", name: "Green Earth NGO (Donation: Story Books)", lastMessage: "Thank you for your contribution!", unread: 2, donationId: "donation2" },
  { id: "chat3", name: "Alice Smith (Donation: Old Tablet)", lastMessage: "Is it still available?", unread: 0, donationId: "donation3" },
];

export default function ChatListPage() {
  return (
    <div className="container mx-auto py-8 px-4 md:px-0">
      <div className="flex items-center mb-8">
        <MessageSquare className="h-8 w-8 text-primary mr-3" />
        <h1 className="text-3xl font-bold text-primary">My Chats</h1>
      </div>
      
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle>Recent Conversations</CardTitle>
          <CardDescription>Manage your communications regarding donations and pickups.</CardDescription>
        </CardHeader>
        <CardContent>
          {mockChats.length > 0 ? (
            <div className="space-y-4">
              {mockChats.map(chat => (
                <Link href={`/chat/${chat.donationId}?with=${chat.id}`} key={chat.id} passHref>
                  <div className="flex items-center p-4 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                    <div className="flex-grow">
                      <p className="font-semibold text-foreground">{chat.name}</p>
                      <p className="text-sm text-muted-foreground truncate">{chat.lastMessage}</p>
                    </div>
                    {chat.unread > 0 && (
                      <span className="ml-4 px-2 py-1 text-xs font-semibold text-primary-foreground bg-primary rounded-full">
                        {chat.unread}
                      </span>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-10">
              <MessageSquare className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg text-muted-foreground">No active chats yet.</p>
              <p className="text-sm text-muted-foreground">Start a conversation by claiming an item or when someone claims your donation.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
