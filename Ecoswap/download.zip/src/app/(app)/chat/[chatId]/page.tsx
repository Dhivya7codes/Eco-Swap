"use client";

import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { ChatInterface } from '@/components/chat/ChatInterface';
import { useAuth } from '@/context/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Loader2 } from 'lucide-react';

// This page would represent a chat related to a specific donation (chatId is donationId here)
// and potentially with a specific user (passed via query param `with`)

export default function IndividualChatPage() {
  const params = useParams();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user, loading } = useAuth();
  
  const donationId = params.chatId as string; // Assuming chatId is the donationId
  const otherUserId = searchParams.get('with') || 'unknown'; // This would be the ID of the other participant

  if (loading) {
    return <div className="flex justify-center items-center min-h-[calc(100vh-8rem)]"><Loader2 className="h-12 w-12 animate-spin text-primary" /></div>;
  }

  if (!user) {
    // Should be redirected by AuthProvider or AppLayout, but as a fallback
    router.push('/login');
    return null;
  }
  
  // In a real app, you'd fetch chat history and other user details here based on donationId and otherUserId
  const otherPartyName = otherUserId === 'donor123' ? 'John Doe' : otherUserId === 'ngo456' ? 'Green Earth NGO' : 'A User';


  return (
    <div className="container mx-auto py-8 px-4 md:px-0 h-[calc(100vh-4rem)] flex flex-col">
      <div className="mb-4">
        <Button onClick={() => router.back()} variant="outline" size="sm">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Chats
        </Button>
      </div>
      <Card className="shadow-xl flex-grow flex flex-col">
        <CardHeader>
          <CardTitle className="text-xl text-primary">Chat regarding Donation ID: {donationId}</CardTitle>
          <p className="text-sm text-muted-foreground">Conversation with: {otherPartyName}</p>
        </CardHeader>
        <CardContent className="flex-grow overflow-hidden p-0 md:p-2">
          <ChatInterface 
            currentUser={user} 
            otherUserId={otherUserId} // This needs to be the actual ID of the other participant
            donationId={donationId}
          />
        </CardContent>
      </Card>
    </div>
  );
}
