"use client";

import { SuggestDonationItemsComponent } from '@/components/ai/SuggestDonationItemsComponent';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Lightbulb } from 'lucide-react';

export default function SuggestDonationsPage() {
  return (
    <div className="container mx-auto py-8 px-4 md:px-0">
      <div className="flex items-center mb-8">
        <Lightbulb className="h-8 w-8 text-primary mr-3" />
        <h1 className="text-3xl font-bold text-primary">AI Donation Suggestions</h1>
      </div>
      <Card className="max-w-2xl mx-auto shadow-xl">
        <CardHeader>
          <CardTitle>Declutter with AI</CardTitle>
          <CardDescription>
            Not sure what to donate? Upload a photo of a cluttered space (like a messy cupboard or a pile of old items),
            and our AI will suggest items that might be suitable for donation!
          </CardDescription>
        </CardHeader>
        <CardContent>
          <SuggestDonationItemsComponent />
        </CardContent>
      </Card>
    </div>
  );
}
