"use client";

import { AddDonationForm } from '@/components/donations/AddDonationForm';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PlusCircle } from 'lucide-react';

export default function AddDonationPage() {
  return (
    <div className="container mx-auto py-8 px-4 md:px-0">
      <div className="flex items-center mb-8">
        <PlusCircle className="h-8 w-8 text-primary mr-3" />
        <h1 className="text-3xl font-bold text-primary">Add New Donation Item</h1>
      </div>
      <Card className="max-w-2xl mx-auto shadow-xl">
        <CardHeader>
          <CardTitle>Item Details</CardTitle>
          <CardDescription>
            Fill in the information below to list your item for donation. 
            Clear and accurate details help us find the right recipient quickly.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <AddDonationForm />
        </CardContent>
      </Card>
    </div>
  );
}
