"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { placeholderDonations } from "@/lib/placeholder-data";
import type { DonationItem } from "@/lib/types";
import { useAuth } from "@/context/AuthContext";
import { ShieldCheck, ListChecks, MessageSquare, Info } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

// Helper to format date
const formatDate = (date?: Date | string): string => {
  if (!date) return 'N/A';
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric'
  });
};

export default function ClaimedItemsPage() {
  const { user, role } = useAuth();
  
  // Filter donations claimed by current user (NGO/Receiver)
  const claimedItems = placeholderDonations.filter(d => 
    (role === 'ngo' && d.claimedByNgoId === user?.id) ||
    (role === 'receiver' && d.claimedByReceiverId === user?.id)
  );

  return (
    <div className="container mx-auto py-8 px-4 md:px-0">
      <div className="flex items-center mb-8">
        <ShieldCheck className="h-8 w-8 text-primary mr-3" />
        <h1 className="text-3xl font-bold text-primary">
          {role === 'ngo' ? "Items Claimed by Your NGO" : "Your Claimed Items"}
        </h1>
      </div>

      {claimedItems.length === 0 ? (
        <Card className="shadow-lg text-center">
           <CardHeader>
            <Info className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <CardTitle>No Claimed Items Yet</CardTitle>
            <CardDescription>You haven&apos;t claimed any items yet. Browse available donations to find items you need.</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/donations" passHref>
              <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                Browse Available Donations
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Your Active Claims</CardTitle>
            <CardDescription>Manage items you&apos;ve claimed and coordinate pickup.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-border">
                <thead className="bg-muted/50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Item</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Donor</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Date Claimed</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-background divide-y divide-border">
                  {claimedItems.map((donation) => (
                    <tr key={donation.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10">
                            <Image 
                              className="h-10 w-10 rounded-md object-cover" 
                              src={donation.imageUrl || `https://picsum.photos/seed/${donation.id}/40/40`} 
                              alt={donation.title} 
                              data-ai-hint="donation item small"
                              width={40} height={40}
                            />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-foreground">{donation.title}</div>
                            <div className="text-xs text-muted-foreground capitalize">{donation.category}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">{donation.donorName || 'Anonymous'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">{formatDate(donation.updatedAt)}</td> {/* Assuming updatedAt is claim date for mock */}
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          donation.status === 'claimed' ? 'bg-yellow-100 text-yellow-800' :
                          donation.status === 'picked up' ? 'bg-blue-100 text-blue-800' :
                          donation.status === 'delivered' ? 'bg-purple-100 text-purple-800' :
                          'bg-gray-100 text-gray-800'
                        } capitalize`}>
                          {donation.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                        <Link href={`/donations/${donation.id}`} passHref>
                          <Button variant="link" className="text-primary p-0 h-auto">View</Button>
                        </Link>
                        <Link href={`/chat/${donation.id}?with=${donation.donorId}`} passHref>
                          <Button variant="link" className="text-accent p-0 h-auto flex items-center">
                            <MessageSquare className="mr-1 h-3 w-3"/> Chat
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
