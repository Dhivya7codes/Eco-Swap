"use client";

import { useParams, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { placeholderDonations, placeholderRepairPartners } from '@/lib/placeholder-data'; // Using placeholder for now
import type { DonationItem, RepairPartner, DonationStatus } from '@/lib/types'; // Ensure DonationStatus is imported
import { ArrowLeft, CalendarDays, CheckCircle, Gift, HandHeart, Layers, Loader2, MapPin, MessageSquare, ShieldCheck, Tag, UserCircle, Wrench, ExternalLink } from 'lucide-react'; // Added Wrench, ExternalLink
import { useAuth } from '@/context/AuthContext';
import { toast } from '@/hooks/use-toast';
import { ChatInterface } from '@/components/chat/ChatInterface'; // Placeholder chat
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'; // Added Alert
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog" // Added AlertDialog

// Helper to format date
const formatDate = (date?: Date | string, includeTime = false): string => {
  if (!date) return 'N/A';
  const options: Intl.DateTimeFormatOptions = {
    year: 'numeric', month: 'long', day: 'numeric'
  };
  if (includeTime) {
    options.hour = '2-digit';
    options.minute = '2-digit';
  }
  return new Date(date).toLocaleDateString('en-US', options);
};

export default function DonationDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { id } = params;
  const [donation, setDonation] = useState<DonationItem | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showChat, setShowChat] = useState(false);
  const [suggestedPartners, setSuggestedPartners] = useState<RepairPartner[]>([]);

  const { user, role } = useAuth();

  useEffect(() => {
    if (id) {
      // Simulate fetching donation details
      const foundDonation = placeholderDonations.find(d => d.id === id);
      setDonation(foundDonation || null);
      if (foundDonation && foundDonation.needsRepair) {
        // Mock finding relevant repair partners based on category and location
        const partners = placeholderRepairPartners.filter(p =>
          (p.specialty === 'general' || p.specialty.includes(foundDonation.category)) &&
          p.location.toLowerCase().includes(foundDonation.location.split(' ')[0].toLowerCase()) // Simple location match
        );
        setSuggestedPartners(partners);
      }
    }
    setIsLoading(false);
  }, [id]);

  const handleClaim = () => {
    if (!user || !donation) return;
    if (role === 'donor') {
      toast({ title: "Action Not Allowed", description: "Donors cannot claim items.", variant: "destructive" });
      return;
    }
     if (donation.status === 'pending repair') {
       toast({ title: "Item Needs Repair", description: "This item needs repair before it can be claimed.", variant: "default" });
       return;
     }
    if (donation.status !== 'available') {
      toast({ title: "Already Claimed", description: "This item is no longer available.", variant: "default" });
      return;
    }

    // Mock claiming logic
    console.log(`User ${user.id} claiming item ${donation.id}`);
    const updatedDonation = { ...donation, status: 'claimed' as const, claimedByNgoId: role === 'ngo' ? user.id : undefined, claimedByReceiverId: role === 'receiver' ? user.id : undefined, updatedAt: new Date() };
    setDonation(updatedDonation);
    // In a real app, update placeholderDonations or refetch, and persist to backend
    const donationIndex = placeholderDonations.findIndex(d => d.id === donation.id);
    if (donationIndex > -1) placeholderDonations[donationIndex] = updatedDonation;

    toast({ title: "Item Claimed!", description: `You've claimed "${donation.title}". Please coordinate pickup with the donor.` });
    setShowChat(true); // Open chat after claiming
  };

  const handleMarkAsRepaired = () => {
     if (!user || !donation || donation.donorId !== user.id) {
        toast({ title: "Action Not Allowed", description: "Only the donor can mark this item as repaired.", variant: "destructive" });
        return;
     }
     if (donation.status !== 'pending repair') {
        toast({ title: "Invalid Status", description: "This item is not marked as needing repair.", variant: "default" });
        return;
     }

     // Mock updating logic
      console.log(`Donor ${user.id} marking item ${donation.id} as repaired`);
      const updatedDonation = { ...donation, status: 'available' as const, condition: 'good' as const, needsRepair: false, damageDescription: undefined, updatedAt: new Date() }; // Assume 'good' condition after repair
      setDonation(updatedDonation);
      // In a real app, update placeholderDonations or refetch, and persist to backend
      const donationIndex = placeholderDonations.findIndex(d => d.id === donation.id);
      if (donationIndex > -1) placeholderDonations[donationIndex] = updatedDonation;

       toast({ title: "Item Updated!", description: `"${donation.title}" has been marked as repaired and is now available for claiming.` });
  };


  if (isLoading) {
    return <div className="flex justify-center items-center min-h-[calc(100vh-8rem)]"><Loader2 className="h-12 w-12 animate-spin text-primary" /></div>;
  }

  if (!donation) {
    return (
      <div className="text-center py-10">
        <Gift className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
        <h2 className="text-2xl font-semibold">Donation Not Found</h2>
        <p className="text-muted-foreground">The donation item you are looking for does not exist or has been removed.</p>
        <Button onClick={() => router.back()} variant="outline" className="mt-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
        </Button>
      </div>
    );
  }

  const canClaim = role !== 'donor' && donation.status === 'available';
  const isDonor = user && donation.donorId === user.id;
  const canChat = user && (isDonor || donation.claimedByNgoId === user.id || donation.claimedByReceiverId === user.id);
  const showRepairSection = donation.needsRepair || donation.status === 'pending repair';

  const getStatusBadge = (status: DonationStatus) => {
      let colorClass = '';
      switch (status) {
          case 'available': colorClass = 'bg-green-500'; break;
          case 'claimed': colorClass = 'bg-yellow-500'; break;
          case 'picked up': colorClass = 'bg-blue-500'; break;
          case 'delivered': colorClass = 'bg-purple-500'; break;
          case 'pending repair': colorClass = 'bg-orange-500'; break;
          default: colorClass = 'bg-gray-500'; break;
      }
      return (
          <Badge className={`text-sm px-3 py-1.5 ${colorClass} text-white capitalize`}>
              Status: {status}
          </Badge>
      );
  };


  return (
    <div className="container mx-auto py-8 px-4 md:px-0">
       <Button onClick={() => router.back()} variant="outline" className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Listings
        </Button>
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <Card className="shadow-xl overflow-hidden">
            <CardHeader className="p-0 relative">
              <Image
                src={donation.imageUrl || `https://picsum.photos/seed/${donation.id}/800/500`}
                alt={donation.title}
                data-ai-hint="donation item large"
                width={800}
                height={500}
                className="object-cover w-full h-64 md:h-96"
              />
              <div className="absolute top-4 right-4 flex flex-col items-end space-y-2">
                 {getStatusBadge(donation.status)}
                 {donation.needsRepair && donation.status !== 'pending repair' && ( // Show only if needs repair AND not already pending
                     <Badge variant="destructive" className="bg-orange-600 border-orange-700 text-white">
                         <Wrench className="h-4 w-4 mr-1.5" /> Needs Repair
                     </Badge>
                 )}
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <CardTitle className="text-3xl font-bold text-primary mb-2">{donation.title}</CardTitle>
              <div className="flex items-center text-sm text-muted-foreground mb-4">
                <UserCircle className="h-4 w-4 mr-1.5" />
                <span>Donated by: {donation.donorName || 'Anonymous Donor'}</span>
                <span className="mx-2">|</span>
                <CalendarDays className="h-4 w-4 mr-1.5" />
                <span>Listed on: {formatDate(donation.createdAt)}</span>
              </div>
              <p className="text-foreground leading-relaxed mb-6">{donation.description}</p>

               {showRepairSection && donation.damageDescription && (
                  <Alert variant="destructive" className="mb-6 bg-orange-50 border-orange-300">
                      <Wrench className="h-5 w-5 text-orange-600" />
                      <AlertTitle className="text-orange-700 font-semibold">Needs Repair</AlertTitle>
                      <AlertDescription className="text-orange-600">
                          {donation.damageDescription}
                      </AlertDescription>
                  </Alert>
               )}


              <h3 className="text-xl font-semibold text-primary mb-3">Item Details</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-foreground/90 mb-6">
                <div className="flex items-center"><Tag className="h-5 w-5 mr-2 text-accent" /><strong>Category:</strong><span className="ml-2 capitalize">{donation.category}</span></div>
                <div className="flex items-center"><ShieldCheck className="h-5 w-5 mr-2 text-accent" /><strong>Condition:</strong><span className="ml-2 capitalize">{donation.condition}</span></div>
                <div className="flex items-center"><Layers className="h-5 w-5 mr-2 text-accent" /><strong>Availability:</strong><span className="ml-2">{donation.availability}</span></div>
                <div className="flex items-center"><MapPin className="h-5 w-5 mr-2 text-accent" /><strong>Location:</strong><span className="ml-2">{donation.location}</span></div>
                {donation.pickupSlot && (
                  <div className="flex items-center col-span-full"><CalendarDays className="h-5 w-5 mr-2 text-accent" /><strong>Preferred Pickup:</strong><span className="ml-2">{formatDate(donation.pickupSlot, true)}</span></div>
                )}
                {donation.ecoPointsValue && (
                  <div className="flex items-center col-span-full"><HandHeart className="h-5 w-5 mr-2 text-accent" /><strong>EcoPoints Value:</strong><span className="ml-2">{donation.ecoPointsValue} points</span></div>
                )}
              </div>
            </CardContent>
            <CardFooter className="p-6 border-t flex flex-wrap gap-2">
              {canClaim && (
                <Button onClick={handleClaim} size="lg" className="flex-1 min-w-[150px] bg-accent text-accent-foreground hover:bg-accent/90">
                  <CheckCircle className="mr-2 h-5 w-5" /> Claim This Item
                </Button>
              )}
              {!canClaim && donation.status !== 'available' && donation.status !== 'pending repair' && (
                <Badge variant="outline" className="text-yellow-600 border-yellow-400 bg-yellow-50 text-base py-2 px-4">This item has already been {donation.status}.</Badge>
              )}
               {isDonor && donation.status !== 'pending repair' && (
                <Badge variant="outline" className="text-blue-600 border-blue-400 bg-blue-50 text-base py-2 px-4">You listed this item for donation.</Badge>
              )}
              {isDonor && donation.status === 'pending repair' && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                     <Button size="lg" variant="outline" className="flex-1 min-w-[150px] border-green-500 text-green-600 hover:bg-green-50 hover:text-green-700">
                      <CheckCircle className="mr-2 h-5 w-5" /> Mark as Repaired
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Confirm Item Repaired?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Marking this item as repaired will change its status to 'available' and make it claimable by others. Please ensure the repair is complete.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleMarkAsRepaired} className="bg-green-600 hover:bg-green-700">Confirm Repaired</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
               {donation.status === 'pending repair' && role !== 'donor' && (
                 <Badge variant="outline" className="text-orange-600 border-orange-400 bg-orange-50 text-base py-2 px-4">Item requires repair before claiming.</Badge>
               )}
            </CardFooter>
          </Card>
        </div>

        <div className="md:col-span-1 space-y-6">
            {/* Donor Info Card */}
            <Card className="shadow-lg">
                <CardHeader>
                    <CardTitle className="text-xl text-primary">Donor Information</CardTitle>
                </CardHeader>
                <CardContent>
                    <p><strong>Name:</strong> {donation.donorName || 'Anonymous'}</p>
                    { (donation.status !== 'available' && donation.status !== 'pending repair' && canChat) && <p className="text-sm text-muted-foreground mt-2">Contact donor via chat for pickup.</p> }
                     { !(donation.status !== 'available' && donation.status !== 'pending repair' && canChat) && <p className="text-sm text-muted-foreground mt-2">Donor contact visible after claim/repair.</p> }
                </CardContent>
            </Card>

             {/* Fix & Donate Section */}
             {showRepairSection && (
                <Card className="shadow-lg bg-orange-50 border-orange-300">
                    <CardHeader>
                        <CardTitle className="text-xl text-orange-700 flex items-center">
                            <Wrench className="mr-2 h-6 w-6" /> Fix & Donate Options
                        </CardTitle>
                        <CardDescription className="text-orange-600">
                           {isDonor ? "Find local partners to help repair this item before donating." : "This item needs repair. The donor may be looking for repair options."}
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                         {suggestedPartners.length > 0 ? (
                            <div className="space-y-3">
                                <p className="text-sm font-medium text-orange-800">Suggested Repair Partners Near '{donation.location}':</p>
                                {suggestedPartners.map(partner => (
                                    <div key={partner.id} className="p-3 border rounded-md bg-white shadow-sm">
                                        <p className="font-semibold text-primary">{partner.name}</p>
                                        <p className="text-xs text-muted-foreground capitalize">
                                            Specialty: {Array.isArray(partner.specialty) ? partner.specialty.join(', ') : partner.specialty}
                                        </p>
                                        {partner.contactInfo && <p className="text-xs text-muted-foreground">Contact: {partner.contactInfo}</p> }
                                        {partner.isFreeService && <Badge variant="secondary" className="mt-1 bg-green-100 text-green-700">Volunteer/Free Service</Badge>}
                                         <Button variant="link" size="sm" className="p-0 h-auto mt-1 text-accent text-xs" onClick={() => toast({title: "Contact Partner", description: `Contact info: ${partner.contactInfo || 'N/A'}`})}>
                                            Contact <ExternalLink className="ml-1 h-3 w-3"/>
                                         </Button>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-sm text-muted-foreground">No specific repair partners found for this category/location in our mock database. Consider searching locally.</p>
                        )}
                        {isDonor && donation.status === 'pending repair' && ( // Show 'Mark as Repaired' button only if donor and pending repair
                             <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button size="sm" variant="outline" className="w-full mt-4 border-green-500 text-green-600 hover:bg-green-50 hover:text-green-700">
                                  <CheckCircle className="mr-2 h-4 w-4" /> I've Repaired This Item
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Confirm Item Repaired?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Marking this item as repaired will change its status to 'available' and make it claimable by others. Please ensure the repair is complete.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction onClick={handleMarkAsRepaired} className="bg-green-600 hover:bg-green-700">Confirm Repaired</AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                        )}
                    </CardContent>
                </Card>
             )}


            {/* Claimed By Card */}
            { (donation.status !== 'available' && donation.status !== 'pending repair' && (donation.claimedByNgoId || donation.claimedByReceiverId)) && (
                 <Card className="shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-xl text-primary">Claimed By</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p><strong>Name:</strong> {donation.claimedByNgoId ? "NGO XYZ" : "Receiver ABC"  /* Fetch actual name */}</p>
                        <p className="text-sm text-muted-foreground mt-2">Contact via chat for pickup coordination.</p>
                    </CardContent>
                </Card>
            )}

            {/* Chat Section */}
            {canChat && (
                <Button onClick={() => setShowChat(s => !s)} variant="outline" className="w-full">
                    <MessageSquare className="mr-2 h-5 w-5" /> {showChat ? "Hide Chat" : "Open Chat"}
                </Button>
            )}
            {showChat && canChat && (
              <Card className="shadow-lg">
                <CardHeader><CardTitle>Chat</CardTitle></CardHeader>
                <CardContent>
                  <ChatInterface
                    currentUser={user!}
                    otherUserId={user!.id === donation.donorId ? (donation.claimedByNgoId || donation.claimedByReceiverId || 'unknown-recipient') : donation.donorId}
                    donationId={donation.id}
                  />
                </CardContent>
              </Card>
            )}
        </div>
      </div>
    </div>
  );
}
