"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { placeholderDonations } from "@/lib/placeholder-data";
import type { DonationItem } from "@/lib/types";
import { useAuth } from "@/context/AuthContext";
import { Zap, ListOrdered, Download, Info } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

// Helper to format date
const formatDate = (date?: Date | string): string => {
  if (!date) return 'N/A';
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric'
  });
};

export default function DonationHistoryPage() {
  const { user } = useAuth();
  
  // Filter donations by current user (donor)
  const myDonations = placeholderDonations.filter(d => d.donorId === user?.id);

  return (
    <div className="container mx-auto py-8 px-4 md:px-0">
      <div className="flex items-center mb-8">
        <Zap className="h-8 w-8 text-primary mr-3" />
        <h1 className="text-3xl font-bold text-primary">My Donation History</h1>
      </div>

      {myDonations.length === 0 ? (
        <Card className="shadow-lg text-center">
          <CardHeader>
            <Info className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <CardTitle>No Donations Yet</CardTitle>
            <CardDescription>You haven&apos;t made any donations through EcoSwap yet. Start today and make an impact!</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/donations/add" passHref>
              <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                Make Your First Donation
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Your Contributions</CardTitle>
              <CardDescription>A summary of all items you&apos;ve listed for donation.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-border">
                  <thead className="bg-muted/50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Item</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Date Listed</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">EcoPoints</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-background divide-y divide-border">
                    {myDonations.map((donation) => (
                      <tr key={donation.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              <Image 
                                className="h-10 w-10 rounded-md object-cover" 
                                src={donation.imageUrl || `https://picsum.photos/seed/${donation.id}/40/40`} 
                                alt={donation.title}
                                data-ai-hint="donation item small" 
                                width={40} height={40} 
                              />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-foreground">{donation.title}</div>
                              <div className="text-xs text-muted-foreground capitalize">{donation.category}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">{formatDate(donation.createdAt)}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            donation.status === 'available' ? 'bg-green-100 text-green-800' :
                            donation.status === 'claimed' ? 'bg-yellow-100 text-yellow-800' :
                            donation.status === 'picked up' ? 'bg-blue-100 text-blue-800' :
                            donation.status === 'delivered' ? 'bg-purple-100 text-purple-800' :
                            'bg-gray-100 text-gray-800'
                          } capitalize`}>
                            {donation.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground text-center">{donation.ecoPointsValue || '-'}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <Link href={`/donations/${donation.id}`} passHref>
                            <Button variant="link" className="text-primary p-0 h-auto">View Details</Button>
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center"><Download className="mr-2 h-5 w-5 text-primary"/> Impact Report (Coming Soon)</CardTitle>
              <CardDescription>Download a summary of your donation impact for CSR or personal records.</CardDescription>
            </CardHeader>
            <CardContent>
              <Button disabled>Generate Report PDF</Button>
              <p className="text-xs text-muted-foreground mt-2">This feature will be available in a future update.</p>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
