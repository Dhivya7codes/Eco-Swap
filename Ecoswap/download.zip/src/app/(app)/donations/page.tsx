
"use client";

import { DonationList } from '@/components/donations/DonationList';
import { placeholderDonations } from '@/lib/placeholder-data';
import type { DonationItem } from '@/lib/types';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, ListFilter, MapPin, Tag, Loader2, Gift } from 'lucide-react'; // Import Loader2 and Gift
import { useState, useEffect } from 'react';

// Simulate fetching donations
async function fetchDonations(): Promise<DonationItem[]> {
  // In a real app, this would be an API call
  await new Promise(resolve => setTimeout(resolve, 500));
  return placeholderDonations;
}

export default function DonationsPage() {
  const [donations, setDonations] = useState<DonationItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [locationFilter, setLocationFilter] = useState('');


  useEffect(() => {
    async function loadDonations() {
      setIsLoading(true);
      const fetchedDonations = await fetchDonations();
      setDonations(fetchedDonations);
      setIsLoading(false);
    }
    loadDonations();
  }, []);

  const filteredDonations = donations.filter(donation => {
    const matchesSearch = donation.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          donation.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || donation.category === categoryFilter;
    const matchesLocation = locationFilter === '' || donation.location.toLowerCase().includes(locationFilter.toLowerCase());
    return matchesSearch && matchesCategory && matchesLocation && donation.status === 'available';
  });

  const categories = ['all', ...new Set(placeholderDonations.map(d => d.category))];

  return (
    <div className="container mx-auto py-8 px-4 md:px-0">
      <header className="mb-8">
        <h1 className="text-4xl font-bold text-primary mb-2">Browse Donations</h1>
        <p className="text-lg text-muted-foreground">Find items you can claim and give a new life.</p>
      </header>

      <div className="mb-8 p-6 bg-card rounded-xl shadow-lg">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <div className="lg:col-span-2">
            <label htmlFor="search" className="block text-sm font-medium text-foreground mb-1">Search Donations</label>
            <div className="relative">
              <Input
                id="search"
                type="text"
                placeholder="Search by title or description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            </div>
          </div>
          <div>
            <label htmlFor="category" className="block text-sm font-medium text-foreground mb-1">Category</label>
            <div className="relative">
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger id="category" className="pl-10">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat} value={cat} className="capitalize">
                      {cat === 'all' ? 'All Categories' : (cat.charAt(0).toUpperCase() + cat.slice(1))}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Tag className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            </div>
          </div>
          <div>
            <label htmlFor="location" className="block text-sm font-medium text-foreground mb-1">Location</label>
             <div className="relative">
              <Input
                id="location"
                type="text"
                placeholder="Enter city or area..."
                value={locationFilter}
                onChange={(e) => setLocationFilter(e.target.value)}
                className="pl-10"
              />
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            </div>
          </div>
          {/* <Button variant="outline" className="lg:col-start-4">
            <ListFilter className="mr-2 h-4 w-4" /> More Filters
          </Button> */}
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center py-10">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4 text-lg text-muted-foreground">Loading donations...</p>
        </div>
      ) : filteredDonations.length > 0 ? (
        <DonationList donations={filteredDonations} />
      ) : (
        <div className="text-center py-10">
          <Gift className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
          <h2 className="text-2xl font-semibold text-foreground mb-2">No Donations Found</h2>
          <p className="text-muted-foreground">
            No items match your current filters, or there are no available donations at the moment.
            <br/>Try adjusting your search or check back later!
          </p>
        </div>
      )}
    </div>
  );
}
