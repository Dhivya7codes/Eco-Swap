"use client";

import { EditProfileForm } from '@/components/profile/EditProfileForm';
import { useAuth } from '@/context/AuthContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Award, ShieldCheck, Star } from 'lucide-react';

export default function ProfilePage() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <p>Loading profile...</p>
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary ml-2"></div>
      </div>
    );
  }

  if (!user) {
    return <p>User not found. Please log in.</p>;
  }

  return (
    <div className="container mx-auto py-8 px-4 md:px-0">
      <h1 className="text-3xl font-bold mb-8 text-primary">My Profile</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <Card className="shadow-lg">
            <CardHeader className="items-center text-center">
              <Avatar className="h-32 w-32 mb-4 border-4 border-primary shadow-md">
                <AvatarImage src={user.profilePicUrl || undefined} alt={user.name} data-ai-hint="profile avatar" />
                <AvatarFallback className="text-4xl">{user.name?.charAt(0).toUpperCase()}</AvatarFallback>
              </Avatar>
              <CardTitle className="text-2xl">{user.name}</CardTitle>
              <CardDescription className="capitalize">{user.role}</CardDescription>
              {user.isVerified && user.role === 'ngo' && (
                <Badge variant="secondary" className="mt-2 bg-green-100 text-green-700 border-green-300">
                  <ShieldCheck className="mr-1 h-4 w-4" /> Verified NGO
                </Badge>
              )}
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              <div className="space-y-2">
                <p><strong>Email:</strong> {user.email}</p>
                <p><strong>Phone:</strong> {user.phone || 'Not provided'}</p>
                <p><strong>Address:</strong> {user.address || 'Not provided'}</p>
                {user.ecoPoints !== undefined && (
                  <p className="flex items-center">
                    <Star className="mr-2 h-5 w-5 text-yellow-400" />
                    <strong>EcoPoints:</strong> {user.ecoPoints}
                  </p>
                )}
              </div>
              {user.badges && user.badges.length > 0 && (
                <div className="mt-4">
                  <h3 className="font-semibold mb-2 text-foreground">Badges:</h3>
                  <div className="flex flex-wrap gap-2">
                    {user.badges.map((badge, index) => (
                      <Badge key={index} variant="outline" className="border-accent text-accent">
                        <Award className="mr-1 h-4 w-4" /> {badge}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        <div className="md:col-span-2">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Edit Profile Information</CardTitle>
              <CardDescription>Update your personal details here. Click save when you&apos;re done.</CardDescription>
            </CardHeader>
            <CardContent>
              <EditProfileForm user={user} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
