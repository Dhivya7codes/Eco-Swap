"use client";

import { ReactNode } from 'react';
import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { Header } from '@/components/layout/Header';
import { Sidebar } from '@/components/layout/Sidebar';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';

export default function AppLayout({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    // This should ideally be handled by the AuthProvider's effect,
    // but as a fallback or for server components that might render before client-side redirect.
    // For client components, router.push in useEffect is preferred.
    if (typeof window !== 'undefined') {
      router.push('/login');
    }
    return null; // or a loading/redirecting state
  }

  return (
    <SidebarProvider defaultOpen={true}>
      <Sidebar />
      <div className="flex flex-col flex-1 md:ml-[3rem] group-data-[sidebar-state=expanded]/sidebar-wrapper:md:ml-[16rem] transition-[margin-left] duration-200 ease-linear">
        <Header />
        <SidebarInset>
          <main className="flex-1 p-4 sm:p-6 lg:p-8 bg-background min-h-[calc(100vh-4rem)]">
            {children}
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
