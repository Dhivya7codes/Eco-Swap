
"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import Image from "next/image";
import { Gift, HandHeart, Users, BarChart3, PlusCircle, Clock, ExternalLink, Wrench } from "lucide-react"; // Added Wrench
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { PendingRepairsSection } from "@/components/dashboard/PendingRepairsSection"; // Import new component


export default function DashboardPage() {
  const { user, role } = useAuth();

  if (!user) {
    return (
      <div className="flex items-center justify-center h-full">
        <p>Loading user data...</p>
      </div>
    );
  }

  const QuickAction = ({ href, icon: Icon, title, description }: { href: string, icon: React.ElementType, title: string, description: string }) => (
    <Link href={href} passHref>
      <Card className="hover:shadow-lg transition-shadow duration-200 cursor-pointer h-full flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-lg font-medium text-primary">{title}</CardTitle>
          <Icon className="h-6 w-6 text-accent" />
        </CardHeader>
        <CardContent className="flex-grow">
          <p className="text-sm text-muted-foreground">{description}</p>
        </CardContent>
      </Card>
    </Link>
  );

  return (
    <div className="container mx-auto py-8 px-4 md:px-0">
      <div className="mb-8 p-6 bg-gradient-to-r from-primary/80 to-accent/80 text-primary-foreground rounded-xl shadow-lg">
        <h1 className="text-4xl font-bold">Welcome back, {user.name}!</h1>
        <p className="text-lg mt-2">You are logged in as a {role}. Let&apos;s make a difference today!</p>
        {user.ecoPoints && (
          <p className="text-md mt-1">Your EcoPoints: <span className="font-semibold text-yellow-300">{user.ecoPoints}</span></p>
        )}
      </div>

      {role === "donor" && (
        <Alert className="mb-8 bg-yellow-50 border-yellow-300 text-yellow-800 shadow-md">
           <Clock className="h-5 w-5 text-yellow-600" />
           <AlertTitle className="text-yellow-700 font-semibold flex items-center">
             Limited Time Offer! Earn Rewards!
           </AlertTitle>
          <AlertDescription>
             Donate within the next hour and get a <strong className="font-semibold">₹1000 offer code</strong> for Amazon! Make a difference and get rewarded.
             <Button asChild size="sm" variant="link" className="p-0 h-auto ml-2 text-yellow-700 hover:text-yellow-800">
               <Link href="/donations/add">
                 Donate Now <ExternalLink className="ml-1 h-3 w-3" />
               </Link>
             </Button>
          </AlertDescription>
        </Alert>
      )}


      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-4 text-foreground">Quick Actions</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {role === "donor" && (
            <QuickAction href="/donations/add" icon={PlusCircle} title="Make a Donation" description="List an item you'd like to donate." />
          )}
          { (role === "ngo" || role === "receiver") && (
            <QuickAction href="/donations" icon={Gift} title="Find Donations" description="Browse available items to claim." />
          )}
          <QuickAction href="/profile" icon={Users} title="My Profile" description="View and edit your personal information." />
          <QuickAction href="/leaderboard" icon={BarChart3} title="View Leaderboard" description="See top contributors in our community." />
        </div>
      </section>

      {role === "donor" && (
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4 text-foreground flex items-center">
            <Wrench className="mr-3 h-7 w-7 text-orange-600" />
            Your Items Pending Repair
          </h2>
          <PendingRepairsSection userId={user.id} />
        </section>
      )}

      <section>
        <h2 className="text-2xl font-semibold mb-4 text-foreground">Impact Overview</h2>
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-primary">Your Recent Activity</CardTitle>
              <CardDescription>Highlights of your contributions and interactions.</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Placeholder content */}
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>You listed "Winter Clothes" for donation 2 days ago.</li>
                {role === "ngo" && <li>You claimed "Story Books" 1 day ago.</li>}
                {role === "receiver" && <li>You received "Study Table" 3 days ago.</li>}
                <li>You earned 50 EcoPoints this week.</li>
              </ul>
              <Button variant="link" className="p-0 h-auto mt-4 text-accent">View all activity</Button>
            </CardContent>
          </Card>
          <Card className="bg-primary/10 border-primary/30">
             <CardHeader>
              <CardTitle className="text-xl text-primary flex items-center"><HandHeart className="mr-2 h-6 w-6" /> Inspire Others</CardTitle>
              <CardDescription>Share your donation stories and motivate the community.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center text-center">
              <Image src="https://placehold.co/400x250.png" data-ai-hint="charity community" alt="Community Impact" width={400} height={250} className="rounded-lg mb-4 shadow-md"/>
              <p className="text-sm text-muted-foreground mb-4">
                Your contributions create a ripple effect of kindness. Consider sharing your positive experiences on our "Reuse Story" feature once it's live!
              </p>
              <Button className="bg-accent text-accent-foreground hover:bg-accent/90">Learn More (Coming Soon)</Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
