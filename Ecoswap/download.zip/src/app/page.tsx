"use client";

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext'; // To be created
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import Link from 'next/link';
import { Leaf, Users, ArrowRight } from 'lucide-react';

export default function HomePage() {
  const router = useRouter();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && user) {
      // router.push('/dashboard'); // Uncomment when dashboard is ready
    }
  }, [user, loading, router]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-background to-secondary/30 p-6 text-center">
      <header className="mb-12">
        <div className="flex items-center justify-center mb-4">
          <Leaf className="h-16 w-16 text-primary" />
          <h1 className="text-5xl font-bold text-primary ml-3">EcoSwap</h1>
        </div>
        <p className="text-xl text-foreground/80">Turn Waste into Worth. Connect. Donate. Inspire.</p>
      </header>

      <main className="mb-12 max-w-2xl">
        <Image
          src="https://picsum.photos/800/400?random=1"
          alt="Community donation drive"
          data-ai-hint="community environment"
          width={800}
          height={400}
          className="rounded-xl shadow-2xl mb-8"
        />
        <p className="text-lg text-foreground/70 mb-8">
          EcoSwap is a platform that connects donors with NGOs and receivers, making it easy to give pre-loved items a new life. Join us in building a sustainable future, one donation at a time.
        </p>
      </main>

      <footer className="flex flex-col sm:flex-row gap-4">
        {user ? (
           <Link href="/dashboard" passHref>
            <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
              Go to Dashboard <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        ) : (
          <>
            <Link href="/login" passHref>
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
                Login <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/signup" passHref>
              <Button variant="outline" size="lg" className="border-primary text-primary hover:bg-primary/10">
                Sign Up <Users className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </>
        )}
      </footer>
    </div>
  );
}
