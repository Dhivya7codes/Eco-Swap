"use client";

import { LoginForm } from '@/components/auth/LoginForm';
import { Leaf } from 'lucide-react';
import Link from 'next/link';

export default function LoginPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-background to-secondary/30 p-6">
      <div className="mx-auto flex w-full flex-col justify-center space-y-6 sm:w-[400px] bg-card p-8 rounded-xl shadow-2xl">
        <div className="flex flex-col space-y-2 text-center">
          <Leaf className="mx-auto h-12 w-12 text-primary" />
          <h1 className="text-3xl font-semibold tracking-tight text-primary">
            Welcome Back to EcoSwap
          </h1>
          <p className="text-sm text-muted-foreground">
            Enter your credentials to access your account.
          </p>
        </div>
        <LoginForm />
        <p className="px-8 text-center text-sm text-muted-foreground">
          Don&apos;t have an account?{' '}
          <Link
            href="/signup"
            className="underline underline-offset-4 hover:text-primary"
          >
            Sign Up
          </Link>
        </p>
      </div>
    </div>
  );
}
