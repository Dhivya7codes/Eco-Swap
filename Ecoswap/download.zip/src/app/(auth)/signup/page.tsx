"use client";

import { SignupForm } from '@/components/auth/SignupForm';
import { Leaf } from 'lucide-react';
import Link from 'next/link';

export default function SignupPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-background to-secondary/30 p-6">
      <div className="mx-auto flex w-full flex-col justify-center space-y-6 sm:w-[400px] bg-card p-8 rounded-xl shadow-2xl">
        <div className="flex flex-col space-y-2 text-center">
          <Leaf className="mx-auto h-12 w-12 text-primary" />
          <h1 className="text-3xl font-semibold tracking-tight text-primary">
            Join EcoSwap Today
          </h1>
          <p className="text-sm text-muted-foreground">
            Create an account to start making a difference.
          </p>
        </div>
        <SignupForm />
        <p className="px-8 text-center text-sm text-muted-foreground">
          Already have an account?{' '}
          <Link
            href="/login"
            className="underline underline-offset-4 hover:text-primary"
          >
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}
