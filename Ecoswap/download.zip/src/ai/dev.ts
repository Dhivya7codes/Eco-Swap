import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-donation-items.ts';