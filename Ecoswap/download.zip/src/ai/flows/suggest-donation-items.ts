// 'use server'
'use server';
/**
 * @fileOverview An AI agent that suggests donation items from a photo of a cluttered space.
 *
 * - suggestDonationItems - A function that handles the suggestion of donation items.
 * - SuggestDonationItemsInput - The input type for the suggestDonationItems function.
 * - SuggestDonationItemsOutput - The return type for the suggestDonationItems function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestDonationItemsInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of a cluttered space, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type SuggestDonationItemsInput = z.infer<typeof SuggestDonationItemsInputSchema>;

const SuggestDonationItemsOutputSchema = z.object({
  suggestedItems: z
    .array(z.string())
    .describe('A list of items suggested for donation.'),
});
export type SuggestDonationItemsOutput = z.infer<typeof SuggestDonationItemsOutputSchema>;

export async function suggestDonationItems(
  input: SuggestDonationItemsInput
): Promise<SuggestDonationItemsOutput> {
  return suggestDonationItemsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestDonationItemsPrompt',
  input: {schema: SuggestDonationItemsInputSchema},
  output: {schema: SuggestDonationItemsOutputSchema},
  prompt: `You are a helpful AI assistant that suggests items for donation based on a photo of a cluttered space.

  Analyze the image and suggest items that the user might want to donate. Be specific and list the items clearly.

  Photo: {{media url=photoDataUri}}`,
});

const suggestDonationItemsFlow = ai.defineFlow(
  {
    name: 'suggestDonationItemsFlow',
    inputSchema: SuggestDonationItemsInputSchema,
    outputSchema: SuggestDonationItemsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
