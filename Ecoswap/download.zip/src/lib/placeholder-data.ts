import type { DonationItem, LeaderboardEntry, UserProfile, RepairPartner } from './types';

export const placeholderDonations: DonationItem[] = [
  {
    id: 'donation1',
    title: 'Warm Winter Jackets',
    description: 'Collection of gently used winter jackets, suitable for adults and children. Various sizes.',
    category: 'clothing',
    condition: 'good',
    location: 'Eco City Downtown',
    imageUrl: 'https://picsum.photos/seed/jackets/300/200',
    availability: '5 jackets',
    donorId: 'donor123',
    donorName: 'John Doe',
    status: 'available',
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    ecoPointsValue: 50,
    needsRepair: false,
  },
  {
    id: 'donation2',
    title: 'Children\'s Story Books',
    description: 'A box of 20+ children\'s story books for ages 3-8. Excellent condition.',
    category: 'books',
    condition: 'like new',
    location: 'Maple Suburbs',
    imageUrl: 'https://picsum.photos/seed/books/300/200',
    availability: '1 box',
    donorId: 'donor456',
    donorName: 'Jane Smith',
    status: 'claimed',
    claimedByNgoId: 'ngo456',
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
    updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
    ecoPointsValue: 30,
    needsRepair: false,
  },
  {
    id: 'donation3',
    title: 'Old Android Tablet (Needs Repair)',
    description: 'Working Android tablet, 5 years old. Screen flickers occasionally, otherwise fine. Includes charger.',
    category: 'electronics',
    condition: 'needs repair', // Changed condition
    location: 'Tech Park Area',
    imageUrl: 'https://picsum.photos/seed/tablet/300/200',
    availability: '1 tablet',
    donorId: 'donor789',
    donorName: 'Robert Brown',
    status: 'pending repair', // Changed status
    claimedByReceiverId: undefined, // Reset claimed status as it's pending repair now
    createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // Updated recently
    ecoPointsValue: 10, // Reduced points due to condition
    needsRepair: true, // Set needsRepair flag
    damageDescription: 'Screen flickers intermittently, especially when brightness is high.', // Added damage description
  },
  {
    id: 'donation4',
    title: 'Office Chair',
    description: 'Ergonomic office chair, good condition, some minor wear and tear.',
    category: 'furniture',
    condition: 'good',
    location: 'Green Valley Offices',
    imageUrl: 'https://picsum.photos/seed/chair/300/200',
    availability: '1 chair',
    donorId: 'donor123',
    donorName: 'John Doe',
    status: 'available',
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
    updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    ecoPointsValue: 40,
    needsRepair: false,
  },
   {
    id: 'donation5',
    title: 'Torn Cotton Shirt',
    description: 'Branded cotton shirt with a tear under the armpit. Otherwise clean and good material.',
    category: 'clothing',
    condition: 'needs repair',
    location: 'Eco City Downtown',
    imageUrl: 'https://picsum.photos/seed/shirt/300/200',
    availability: '1 shirt',
    donorId: 'donor456',
    donorName: 'Jane Smith',
    status: 'pending repair',
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    ecoPointsValue: 5,
    needsRepair: true,
    damageDescription: 'Approx 5cm tear along the seam under the left armpit.',
  },
];

export const placeholderLeaderboard: LeaderboardEntry[] = [
  {
    rank: 1,
    userId: 'donor123',
    userName: 'John Doe',
    userProfilePicUrl: 'https://picsum.photos/seed/donor/40/40',
    ecoPoints: 1250,
    userRole: 'donor',
  },
  {
    rank: 2,
    userId: 'donor456',
    userName: 'Jane Smith',
    userProfilePicUrl: 'https://picsum.photos/seed/jsmith/40/40',
    ecoPoints: 980, // Adjusted points based on items
    userRole: 'donor',
  },
  {
    rank: 3,
    userId: 'donor789',
    userName: 'Robert Brown',
    userProfilePicUrl: 'https://picsum.photos/seed/rbrown/40/40',
    ecoPoints: 750,
    userRole: 'donor',
  },
   {
    rank: 4,
    userId: 'ngo456',
    userName: 'Green Earth Foundation',
    userProfilePicUrl: 'https://picsum.photos/seed/ngo/40/40',
    ecoPoints: 500, // Points could be for facilitating donations
    userRole: 'ngo',
  },
  {
    rank: 5,
    userId: 'donor101',
    userName: 'Emily White',
    userProfilePicUrl: 'https://picsum.photos/seed/ewhite/40/40',
    ecoPoints: 450,
    userRole: 'donor',
  },
];

export const placeholderUserProfile: UserProfile = {
  id: 'user123',
  name: 'Alex Green',
  email: 'alex.green@example.com',
  role: 'donor',
  address: '123 Recycle Road, Eco City, 12345',
  phone: '555-0123',
  profilePicUrl: 'https://picsum.photos/seed/alexgreen/200/200',
  ecoPoints: 850,
  badges: ['Eco Warrior', 'Community Helper', 'Recycle Pro'],
};

// Mock Repair Partners for "Fix & Donate"
export const placeholderRepairPartners: RepairPartner[] = [
  {
    id: 'repair1',
    name: 'Stitch It Good',
    specialty: ['clothing'],
    location: 'Eco City Downtown',
    contactInfo: '555-STITCH',
    isFreeService: false,
  },
  {
    id: 'repair2',
    name: 'Electronics Rescue',
    specialty: ['electronics'],
    location: 'Tech Park Area',
    contactInfo: 'fixit@electronicsrescue.com',
    isFreeService: false,
  },
  {
    id: 'repair3',
    name: 'Community Fixers (Volunteer Group)',
    specialty: 'general',
    location: 'Maple Suburbs Community Hall',
    contactInfo: 'communityfixers@mail.com',
    isFreeService: true,
  },
   {
    id: 'repair4',
    name: 'Furniture Refresh',
    specialty: ['furniture'],
    location: 'Green Valley Offices',
    contactInfo: '555-FURNISH',
    isFreeService: false,
  },
];
