export type UserRole = "donor" | "ngo" | "receiver";

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  address?: string;
  phone?: string;
  profilePicUrl?: string;
  ecoPoints?: number;
  badges?: string[];
  isVerified?: boolean; // For NGOs
}

export type DonationCategory = "clothing" | "electronics" | "furniture" | "books" | "toys" | "kitchenware" | "other";
export type DonationCondition = "new" | "like new" | "good" | "fair" | "needs repair"; // Added "needs repair" condition
export type DonationStatus = "available" | "claimed" | "picked up" | "delivered" | "cancelled" | "pending repair"; // Added "pending repair" status

export interface DonationItem {
  id: string;
  title: string;
  description: string;
  category: DonationCategory;
  condition: DonationCondition;
  location: string; // Could be more complex (e.g., lat/lng)
  imageUrl?: string;
  availability: string; // e.g., "2 bags", "1 item"
  pickupSlot?: Date; // Or string for simplicity
  donorId: string;
  donorName?: string; // Denormalized for display
  claimedByNgoId?: string;
  claimedByReceiverId?: string;
  status: DonationStatus;
  createdAt: Date;
  updatedAt: Date;
  ecoPointsValue?: number;
  needsRepair?: boolean; // Flag to indicate if item needs repair
  damageDescription?: string; // Description of the damage if needsRepair is true
}

export interface ChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: Date;
  isRead?: boolean;
}

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  userName: string;
  userProfilePicUrl?: string;
  ecoPoints: number;
  userRole: UserRole; // To show if it's a donor or organization
}

// Added for "Fix & Donate" feature
export interface RepairPartner {
  id: string;
  name: string;
  specialty: DonationCategory[] | 'general'; // e.g., ['electronics'], ['clothing', 'furniture'], 'general'
  location: string; // e.g., "Eco City Downtown", "Maple Suburbs"
  contactInfo?: string; // Phone or email
  isFreeService?: boolean; // If it's a volunteer group
}
