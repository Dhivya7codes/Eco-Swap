"use client";

import type { UserProfile, UserRole } from '@/lib/types';
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useRouter, usePathname } from 'next/navigation';

interface AuthContextType {
  user: UserProfile | null;
  role: UserRole | null;
  loading: boolean;
  login: (mockRole: UserRole) => void;
  logout: () => void;
  updateProfile: (profile: Partial<UserProfile>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user data for different roles
const mockUsers: Record<UserRole, UserProfile> = {
  donor: {
    id: 'donor123',
    name: 'John Doe',
    email: 'john.doe@example.com',
    role: 'donor',
    address: '123 Green St, Eco City',
    phone: '555-1234',
    profilePicUrl: 'https://picsum.photos/seed/donor/200/200',
    ecoPoints: 1250,
    badges: ['Top Donator Q1', 'Recycle Hero'],
  },
  ngo: {
    id: 'ngo456',
    name: 'Green Earth Foundation',
    email: 'contact@greenearth.org',
    role: 'ngo',
    address: '456 Charity Ave, Hope Town',
    phone: '555-5678',
    profilePicUrl: 'https://picsum.photos/seed/ngo/200/200',
    ecoPoints: 0, // NGOs might not have points this way
    badges: ['Verified NGO', 'Community Champion'],
    isVerified: true,
  },
  receiver: {
    id: 'receiver789',
    name: 'Alice Smith',
    email: 'alice.s@example.com',
    role: 'receiver',
    address: '789 Hope Rd, Kind Village',
    phone: '555-9012',
    profilePicUrl: 'https://picsum.photos/seed/receiver/200/200',
    ecoPoints: 0,
    badges: [],
  },
};


export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [role, setRole] = useState<UserRole | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    // Simulate loading user from storage
    const storedRole = localStorage.getItem('userRole') as UserRole | null;
    if (storedRole && mockUsers[storedRole]) {
      setUser(mockUsers[storedRole]);
      setRole(storedRole);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!loading && !user && !['/login', '/signup', '/'].includes(pathname)) {
      router.push('/login');
    }
  }, [user, loading, pathname, router]);

  const login = (mockRole: UserRole) => {
    setLoading(true);
    const userData = mockUsers[mockRole];
    setUser(userData);
    setRole(mockRole);
    localStorage.setItem('userRole', mockRole); // Persist role for mock
    setLoading(false);
    router.push('/dashboard');
  };

  const logout = () => {
    setUser(null);
    setRole(null);
    localStorage.removeItem('userRole');
    router.push('/login');
  };

  const updateProfile = (profileUpdate: Partial<UserProfile>) => {
    if (user) {
      const updatedUser = { ...user, ...profileUpdate };
      setUser(updatedUser);
      // In a real app, you would save this to your backend
      if (role && mockUsers[role]) { // Update mock user base for persistence in mock
        mockUsers[role] = updatedUser;
      }
    }
  };

  return (
    <AuthContext.Provider value={{ user, role, loading, login, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
